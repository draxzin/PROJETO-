package com.example.projeto24092024;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.am_at1.ActivityGasolina;
import com.example.am_at1.ActivityIMC;
import com.example.am_at1.ActivityMatricula;

public class MainActivity extends AppCompatActivity {

    private Button btCalculadoraIMC, btGasolina, btMatriculaAluno, btFechar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Ajuste de layout para evitar sobreposição com as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicialização dos botões
        btCalculadoraIMC = findViewById(R.id.btIMC);
        btGasolina = findViewById(R.id.btGasolina);
        btMatriculaAluno = findViewById(R.id.btMatricula);
        btFechar = findViewById(R.id.btFechar);

        // Configurando ações para os botões
        btCalculadoraIMC.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ActivityIMC.class);
            startActivity(intent);
        });

        btGasolina.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ActivityGasolina.class);
            startActivity(intent);
        });

        btMatriculaAluno.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, ActivityMatricula.class);
            startActivity(intent);
        });

        btFechar.setOnClickListener(view -> {
            finishAffinity();
            System.exit(0); // Encerra o aplicativo completamente
        });
    }
}
