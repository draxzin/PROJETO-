package com.example.projeto24092024;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ActivityMatricula extends AppCompatActivity {

    Button btHome, btApresentacao, btFechaApp, btEnviar;
    EditText etNome, etRGM, etCurso, etDisciplina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_matricula);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicialização dos EditTexts
        etNome = findViewById(R.id.etNome);
        etRGM = findViewById(R.id.etRGM);
        etCurso = findViewById(R.id.etCurso);
        etDisciplina = findViewById(R.id.etDisciplina);

        // Botão que envia a matrícula
        btEnviar = findViewById(R.id.btEnviar);
        btEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = etNome.getText().toString();
                String rgm = etRGM.getText().toString();
                String curso = etCurso.getText().toString();
                String disciplina = etDisciplina.getText().toString();

                // Aqui você pode fazer o que quiser com os dados
                Toast.makeText(ActivityMatricula.this, "Matrícula Enviada:\n" +
                        "Nome: " + nome + "\n" +
                        "RGM: " + rgm + "\n" +
                        "Curso: " + curso + "\n" +
                        "Disciplina: " + disciplina, Toast.LENGTH_LONG).show();
            }
        });

        // Botão que leva para a MainActivity
        btHome = findViewById(R.id.btHome);
        btHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityMatricula.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Botão que chama o ActivityApresentacao
        btApresentacao = findViewById(R.id.btApresentacao);
        btApresentacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ActivityMatricula.this, ActivityApresentacao.class);
                startActivity(intent);
            }
        });

        // Botão que fecha o aplicativo
        btFechaApp = findViewById(R.id.btFechaApp);
        btFechaApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity(); // Fecha todas as activities
            }
        });
    }
}
