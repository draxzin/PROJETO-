package com.example.projeto24092024;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityIMC extends AppCompatActivity {

    EditText inputPeso, inputAltura;
    Button btCalcular, btLimpar, btVoltar;
    TextView resultadoIMC, classificacaoIMC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        inputPeso = findViewById(R.id.inputPeso);
        inputAltura = findViewById(R.id.inputAltura);
        btCalcular = findViewById(R.id.btCalcular);
        btLimpar = findViewById(R.id.btLimpar);
        btVoltar = findViewById(R.id.btVoltar);
        resultadoIMC = findViewById(R.id.resultadoIMC);
        classificacaoIMC = findViewById(R.id.classificacaoIMC);

        btCalcular.setOnClickListener(v -> {
            String alturaStr = inputAltura.getText().toString();
            String pesoStr = inputPeso.getText().toString();

            // Verificação para garantir que os campos não estão vazios
            if (alturaStr.isEmpty() || pesoStr.isEmpty()) {
                Toast.makeText(ActivityIMC.this, "Por favor, preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                float altura = Float.parseFloat(alturaStr);
                float peso = Float.parseFloat(pesoStr);

                if (altura <= 0 || peso <= 0) {
                    Toast.makeText(ActivityIMC.this, "Valores devem ser maiores que zero", Toast.LENGTH_SHORT).show();
                    return;
                }

                float imc = peso / (altura * altura);
                resultadoIMC.setText(String.format("%.2f", imc));

                if (imc < 18.5) {
                    classificacaoIMC.setText("Abaixo do peso");
                } else if (imc < 25) {
                    classificacaoIMC.setText("Peso normal");
                } else if (imc < 30) {
                    classificacaoIMC.setText("Sobrepeso");
                } else {
                    classificacaoIMC.setText("Obesidade");
                }
            } catch (NumberFormatException e) {
                Toast.makeText(ActivityIMC.this, "Insira valores válidos", Toast.LENGTH_SHORT).show();
            }
        });

        btLimpar.setOnClickListener(v -> {
            inputPeso.setText("");
            inputAltura.setText("");
            resultadoIMC.setText("Resultado IMC");
            classificacaoIMC.setText("Classificação");
        });

        btVoltar.setOnClickListener(v -> finish());
    }
}
