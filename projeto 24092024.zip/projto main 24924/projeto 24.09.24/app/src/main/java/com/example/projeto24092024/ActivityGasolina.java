package com.example.projeto24092024;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ActivityGasolina extends AppCompatActivity {

    Button btHome;
    EditText inputPrecoGasolina, inputPrecoEtanol;
    RadioGroup radioGroup;
    RadioButton rbGasolina, rbEtanol;
    TextView relacaoPreco, melhorCombust;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_gasolina);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicialização dos componentes
        radioGroup = findViewById(R.id.rGOpcoes);
        rbGasolina = findViewById(R.id.rbGasolina);
        rbEtanol = findViewById(R.id.rbEtanol);
        inputPrecoGasolina = findViewById(R.id.tinputPrecoGasolina);
        inputPrecoEtanol = findViewById(R.id.tinputPrecoEtanol);
        relacaoPreco = findViewById(R.id.tvRelacaoPreco);
        melhorCombust = findViewById(R.id.tvMelhorPreco);

        // Listener para o RadioGroup
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> calcularRelacao());

        // Botão Limpar
        Button botaoLimpar = findViewById(R.id.btLimpar);
        botaoLimpar.setOnClickListener(view -> {
            inputPrecoGasolina.setText("");
            inputPrecoEtanol.setText("");
            relacaoPreco.setText("Relação do Preço");
            melhorCombust.setText("Melhor Combustível");
        });

        // Botão para retornar à MainActivity
        btHome = findViewById(R.id.btHome);
        btHome.setOnClickListener(view -> {
            Intent intent = new Intent(ActivityGasolina.this, MainActivity.class);
            startActivity(intent);
        });
    }

    // Método para calcular a relação entre Etanol e Gasolina
    private void calcularRelacao() {
        String gasolinaString = inputPrecoGasolina.getText().toString();
        String etanolString = inputPrecoEtanol.getText().toString();

        // Verifica se os campos estão preenchidos
        if (gasolinaString.isEmpty() || etanolString.isEmpty()) {
            relacaoPreco.setText("Preencha os preços!");
            return;
        }

        // Converte os valores inseridos em double
        double gasolina = Double.parseDouble(gasolinaString);
        double etanol = Double.parseDouble(etanolString);

        // Calcula a relação entre os combustíveis
        double relacaoIdeal = 0.7;
        double relacaoAtual = etanol / gasolina;

        // Verifica qual combustível é mais vantajoso
        if (relacaoAtual <= relacaoIdeal) {
            melhorCombust.setText("Abasteça com Etanol");
        } else {
            melhorCombust.setText("Abasteça com Gasolina");
        }

        // Exibe a diferença percentual
        relacaoPreco.setText("Diferença de " + String.format("%.2f", (relacaoAtual * 100)) + "%");
    }
}
